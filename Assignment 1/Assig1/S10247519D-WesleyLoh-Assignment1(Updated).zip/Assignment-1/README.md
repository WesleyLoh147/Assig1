# Assignment-1
Assignment 1(Webpage of a shop, Includes Motto of the website, products page, sales page, and a homepage)
-Assignment1.html (Home page): Includes the main page of the website, has a slideshow image the changes on click, a navigation bar that allows 
users to go to the next pages.

-aboutus.html (About Us page): Includes a blurred background with text above it, and my website's motto on it. It is stored on a split-screen page.

-Products.html (Products page): Includes all my products stored in product cards with a "Add to Cart" button with a description of each shoe.

-sales.html (Sales page): Includes all my on-sale products stored in a product card with an "Add to Cart" button with a description of each shoe. In this
page the original price is canceled and the sale price is shown in red.

styles.css:  Includes all my styles for my home page, about us page, products page, and sales page. It has the styling for my navigation bar which made them
aligned to the left and the search bar aligned to the right, and when hovering the navigation bar pages change colour. The styles page also has my alignment 
of texts, images and product card.

sciprt.js: Includes my code for my image slider which allows user to click the next button for the image to go next.
 
